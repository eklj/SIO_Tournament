Correctif inscription / connexion — SIO Tournament

Prérequis : les 10 tables PostgreSQL sont déjà créées dans sio_tournament.
Remplacer backend/connexion.php, backend/signin.php et backend/login.php
par les trois fichiers du dossier backend de cette archive.

Dans connexion.php, remplacer TON_MOT_DE_PASSE par le mot de passe de sio_user.
Autre possibilité : fournir SIO_DB_PASSWORD dans l'environnement du serveur PHP.
Ne pas publier le fichier contenant votre mot de passe sur GitHub.

Lancement depuis ~/docs : php -S localhost:8000 -t backend
Inscription : http://localhost:8000/signin.php
Connexion : http://localhost:8000/login.php

Vérification locale :
php -l backend/connexion.php
php -l backend/signin.php
php -l backend/login.php
Puis créer un compte et se connecter avec son pseudo et son mot de passe.
Vérifier aussi le refus d'un pseudo/email déjà utilisé et d'un mauvais mot de passe.

Le rôle attribué à l'inscription est JOUEUR (valeur par défaut de la base).
Les mots de passe sont hachés avec password_hash et vérifiés avec password_verify.
La session définit id_utilisateur et conserve id_joueur pour l'accueil existant.
Les autres pages du projet ne sont pas modifiées.
Ces fichiers n'ont pas été exécutés ici : PHP et PostgreSQL ne sont pas disponibles.
